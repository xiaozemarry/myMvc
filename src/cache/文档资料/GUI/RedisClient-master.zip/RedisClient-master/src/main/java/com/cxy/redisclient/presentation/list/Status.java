package com.cxy.redisclient.presentation.list;

public enum Status {
	Normal, Update, Updating;
}
