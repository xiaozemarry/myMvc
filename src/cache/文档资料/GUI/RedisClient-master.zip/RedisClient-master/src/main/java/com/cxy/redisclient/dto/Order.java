package com.cxy.redisclient.dto;

public enum Order {
	Ascend, Descend;
}
