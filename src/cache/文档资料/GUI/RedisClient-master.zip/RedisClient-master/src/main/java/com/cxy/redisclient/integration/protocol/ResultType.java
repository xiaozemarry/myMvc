package com.cxy.redisclient.integration.protocol;

public enum ResultType {
	Error, Status, Int, Bulk, MultiBulk;
}
