package com.cxy.redisclient.presentation.console;


public class SMembersCmd extends LRangeCmd {

	public SMembersCmd(Console console, String cmd) {
		super(console, cmd);
	}

}
