package com.cxy.redisclient.presentation.zset;

public enum Status {
	Normal, Add, Adding;
}
