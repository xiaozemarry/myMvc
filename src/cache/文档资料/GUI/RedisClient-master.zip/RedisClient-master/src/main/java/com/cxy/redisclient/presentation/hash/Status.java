package com.cxy.redisclient.presentation.hash;

public enum Status {
	Normal, Add, Adding, Edit, Editing;
}
